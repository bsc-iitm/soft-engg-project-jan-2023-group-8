from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
db_dir = "src\instance\database.sqlite3"