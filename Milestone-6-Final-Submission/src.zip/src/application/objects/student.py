from user import User


class Student(User):
    def __init__(self, my_tickets):
        self.my_tickets = my_tickets
        
    def display_tickets(self):
        pass
    
    def create_ticket(query):
        pass
    
    def edit_ticket(ticket_id, query):
        pass
    
    def delete_ticket(ticket_id):
        pass